</div><!-- content -->
{{{extrascripts}}}
<h2>This is the home footer</h2>
</body>
</html>
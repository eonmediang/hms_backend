<!DOCTYPE html>
<html lang="en">
<head>
    <?php get_scripts('header'); ?>
</head>
<body>
	<div class="wrapper">
		<header class="dash-header">
			<!--<h2>This is the header</h2>-->
		</header>
	<div id="content">
<!DOCTYPE html>
<html lang="en" class="homepage">
<head>
    <?php get_scripts('header'); ?>
</head>
<body>
<header class="site-header">
	<h2>This is the home header</h2>
</header>
<div id="content">
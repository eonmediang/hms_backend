		</div><!-- content -->
		<div id="modal-bg">
			<div class="modal-content">
				{{{modals}}}
			</div>
		</div>
		<footer class="dash-footer">
			
		</footer>
	</div><!-- wrapper -->
	<!-- Scripts -->
	<script src="{{{js}}}/script.js"></script>
	{{{extrascripts}}}
<!--<h2>This is the footer</h2>-->
</body>
</html>
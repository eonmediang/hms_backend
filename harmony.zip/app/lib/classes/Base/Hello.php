<?php namespace Base\Hello;

class App {

	public function __construct()
	{
		echo '<h1>This is another app</h1>';
	}
}
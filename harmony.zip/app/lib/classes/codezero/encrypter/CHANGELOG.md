# Changelog

All Notable changes to `Encrypter` will be documented in this file.

## 1.0.0 (2015-03-28)

- Version 1.0.0 of `Encrypter`
- Includes an adapter for Laravel's `Encrypter`
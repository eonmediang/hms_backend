<?php namespace CodeZero\Encrypter; 

use Exception;

class DecryptException extends Exception { }

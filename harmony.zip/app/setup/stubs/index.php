<?php 

require '../app/Core/Init.php';

$app = new \Core\App;

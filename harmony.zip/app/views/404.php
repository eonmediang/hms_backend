<?php

http_response_code(404);

echo '<h1>Page not found!</h1>';